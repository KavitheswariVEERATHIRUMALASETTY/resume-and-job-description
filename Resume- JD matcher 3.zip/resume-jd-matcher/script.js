// File reading utility
function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (e) => reject(e);
        reader.readAsText(file);
    });
}

// Read file as ArrayBuffer
function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (e) => reject(e);
        reader.readAsArrayBuffer(file);
    });
}

// Extract text from PDF file
async function extractTextFromPDF(file) {
    try {
        // Check if PDF.js is loaded
        if (typeof pdfjsLib === 'undefined') {
            throw new Error('PDF.js library is not loaded. Please refresh the page and try again.');
        }

        // Ensure worker is configured
        if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
        }

        const arrayBuffer = await readFileAsArrayBuffer(file);
        const pdf = await pdfjsLib.getDocument({ 
            data: arrayBuffer,
            useSystemFonts: true
        }).promise;
        
        let fullText = '';
        
        // Extract text from all pages
        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const textContent = await page.getTextContent();
            const pageText = textContent.items.map(item => item.str).join(' ');
            fullText += pageText + '\n';
        }
        
        if (!fullText.trim()) {
            throw new Error('No text found in PDF. The file might be image-based or corrupted.');
        }
        
        return fullText.trim();
    } catch (error) {
        console.error('Error extracting text from PDF:', error);
        if (error.message.includes('library')) {
            throw error;
        }
        throw new Error('Failed to extract text from PDF. The file might be corrupted or password-protected.');
    }
}

// Extract text from DOCX file
async function extractTextFromDOCX(file) {
    try {
        // Check if Mammoth.js is loaded
        if (typeof mammoth === 'undefined') {
            throw new Error('Mammoth.js library is not loaded. Please refresh the page and try again.');
        }

        const arrayBuffer = await readFileAsArrayBuffer(file);
        const result = await mammoth.extractRawText({ arrayBuffer: arrayBuffer });
        
        if (!result.value || !result.value.trim()) {
            throw new Error('No text found in DOCX file. The file might be empty or corrupted.');
        }
        
        // Check for warnings
        if (result.messages && result.messages.length > 0) {
            console.warn('DOCX extraction warnings:', result.messages);
        }
        
        return result.value.trim();
    } catch (error) {
        console.error('Error extracting text from DOCX:', error);
        if (error.message.includes('library')) {
            throw error;
        }
        throw new Error('Failed to extract text from DOCX. Please ensure the file is a valid .docx file and not corrupted.');
    }
}

// Handle file upload and extract text based on file type
async function handleFileUpload(file, textareaId, fileNameId) {
    const fileNameElement = document.getElementById(fileNameId);
    const textareaElement = document.getElementById(textareaId);
    
    // Show loading state
    if (fileNameElement) {
        fileNameElement.textContent = `⏳ Processing ${file.name}...`;
        fileNameElement.classList.add('show');
    }
    
    try {
        let extractedText = '';
        const fileExtension = file.name.split('.').pop().toLowerCase();
        
        // Handle different file types
        if (file.type === 'text/plain' || fileExtension === 'txt') {
            // Plain text file
            extractedText = await readFileAsText(file);
        } else if (file.type === 'application/pdf' || fileExtension === 'pdf') {
            // PDF file
            extractedText = await extractTextFromPDF(file);
        } else if (
            file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
            fileExtension === 'docx'
        ) {
            // DOCX file
            extractedText = await extractTextFromDOCX(file);
        } else if (fileExtension === 'doc') {
            // Old .doc format - not directly supported, show message
            throw new Error('Old .doc format is not supported. Please convert to .docx or .pdf format.');
        } else {
            throw new Error('Unsupported file format. Please upload .txt, .pdf, or .docx files.');
        }
        
        // Set extracted text to textarea
        textareaElement.value = extractedText;
        
        // Show success message
        if (fileNameElement) {
            fileNameElement.textContent = `✓ ${file.name} (${extractedText.length} characters extracted)`;
            fileNameElement.classList.add('show');
        }
        
        // Show notification
        showNotification(`Successfully extracted text from ${file.name}`, 'success');
        
    } catch (error) {
        console.error('File processing error:', error);
        
        // Show error message
        if (fileNameElement) {
            fileNameElement.textContent = `✗ Error: ${error.message}`;
            fileNameElement.classList.add('show');
            fileNameElement.style.color = '#dc3545';
        }
        
        // Show error notification
        showNotification(`Error: ${error.message}`, 'error');
        
        // Clear textarea on error
        textareaElement.value = '';
    }
}

// Store current results for export and history
let currentResults = null;
let scoreChart = null;
let skillsChart = null;
let currentResumeId = null;
let editingResumeId = null;

// Optional backend API base URL (if backend is running)
const API_BASE_URL = 'http://localhost:5000/api';

// History Management (localStorage-based)
function saveToHistory(resumeText, jdText, results) {
    try {
        const history = getHistory();
        const historyItem = {
            id: Date.now(),
            date: new Date().toISOString(),
            resumePreview: resumeText.substring(0, 100) + '...',
            jdPreview: jdText.substring(0, 100) + '...',
            score: results.score,
            matchingSkills: results.matchingSkills.length,
            missingSkills: results.missingSkills.length,
            resumeText: resumeText,
            jdText: jdText,
            results: results
        };
        
        history.unshift(historyItem);
        // Keep only last 20 items
        if (history.length > 20) {
            history.pop();
        }
        
        localStorage.setItem('resumeJdHistory', JSON.stringify(history));
        showError('Saved to history successfully!', 'success');
        loadHistory();
    } catch (error) {
        console.error('Error saving to history:', error);
        showError('Failed to save to history. Storage might be full.', 'error');
    }
}

function getHistory() {
    try {
        const history = localStorage.getItem('resumeJdHistory');
        return history ? JSON.parse(history) : [];
    } catch (error) {
        console.error('Error loading history:', error);
        return [];
    }
}

function loadHistory() {
    const history = getHistory();
    const historyList = document.getElementById('history-list');
    const historySection = document.getElementById('history-section');
    
    if (!historyList || !historySection) return;
    
    if (history.length === 0) {
        historySection.classList.add('hidden');
        historyList.innerHTML = '';
        return;
    }
    
    historySection.classList.remove('hidden');
    historyList.innerHTML = '';
    
    history.forEach(item => {
        const historyItem = document.createElement('div');
        historyItem.className = 'history-item';
        
        const loadBtn = document.createElement('button');
        loadBtn.className = 'history-item-btn load';
        loadBtn.textContent = 'Load';
        loadBtn.addEventListener('click', () => loadFromHistory(item.id));
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'history-item-btn delete';
        deleteBtn.textContent = 'Delete';
        deleteBtn.addEventListener('click', () => deleteFromHistory(item.id));
        
        historyItem.innerHTML = `
            <div class="history-item-header">
                <div class="history-item-title">Match Analysis</div>
                <div class="history-item-score">${item.score}%</div>
            </div>
            <div class="history-item-date">${new Date(item.date).toLocaleString()}</div>
            <div class="history-item-preview">
                <strong>Resume:</strong> ${escapeHtml(item.resumePreview)}<br>
                <strong>JD:</strong> ${escapeHtml(item.jdPreview)}
            </div>
            <div class="history-item-actions">
            </div>
        `;
        
        const actionsDiv = historyItem.querySelector('.history-item-actions');
        actionsDiv.appendChild(loadBtn);
        actionsDiv.appendChild(deleteBtn);
        
        historyList.appendChild(historyItem);
    });
}

// Helper function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
}

function loadFromHistory(id) {
    const history = getHistory();
    const item = history.find(h => h.id === id);
    
    if (item) {
        document.getElementById('resume-input').value = item.resumeText;
        document.getElementById('jd-input').value = item.jdText;
        showError('Loaded from history!', 'success');
        
        // Auto-match
        setTimeout(() => {
            document.getElementById('match-btn').click();
        }, 500);
    }
}

function deleteFromHistory(id) {
    if (confirm('Are you sure you want to delete this history item?')) {
        try {
            const history = getHistory();
            const filtered = history.filter(h => h.id !== id);
            localStorage.setItem('resumeJdHistory', JSON.stringify(filtered));
            loadHistory();
            showError('Deleted from history!', 'success');
        } catch (error) {
            console.error('Error deleting from history:', error);
            showError('Failed to delete history item. Please try again.', 'error');
        }
    }
}

function clearAllHistory() {
    if (confirm('Are you sure you want to clear all history? This cannot be undone.')) {
        try {
            localStorage.removeItem('resumeJdHistory');
            loadHistory();
            showError('All history cleared!', 'success');
        } catch (error) {
            console.error('Error clearing history:', error);
            showError('Failed to clear history. Please try again.', 'error');
        }
    }
}

// Export to PDF
function exportToPDF() {
    if (!currentResults) {
        showError('No results to export. Please run a match first.', 'warning');
        return;
    }
    
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Title
        doc.setFontSize(20);
        doc.setTextColor(102, 126, 234);
        doc.text('Resume & JD Match Report', 105, 20, { align: 'center' });
        
        // Score
        doc.setFontSize(16);
        doc.setTextColor(0, 0, 0);
        doc.text(`Match Score: ${currentResults.score}%`, 20, 40);
        
        // Statistics
        let yPos = 60;
        doc.setFontSize(12);
        doc.text(`Matching Skills: ${currentResults.matchingSkills.length}`, 20, yPos);
        yPos += 10;
        doc.text(`Missing Skills: ${currentResults.missingSkills.length}`, 20, yPos);
        yPos += 10;
        doc.text(`Matching Keywords: ${currentResults.matchingKeywords.length}`, 20, yPos);
        yPos += 10;
        doc.text(`Total JD Keywords: ${currentResults.totalKeywords}`, 20, yPos);
        yPos += 20;
        
        // Matching Skills
        doc.setFontSize(14);
        doc.setTextColor(40, 167, 69);
        doc.text('Matching Skills:', 20, yPos);
        yPos += 10;
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        currentResults.matchingSkills.forEach((skill, index) => {
            if (yPos > 270) {
                doc.addPage();
                yPos = 20;
            }
            doc.text(`• ${skill}`, 25, yPos);
            yPos += 7;
        });
        yPos += 10;
        
        // Missing Skills
        if (currentResults.missingSkills.length > 0) {
            if (yPos > 270) {
                doc.addPage();
                yPos = 20;
            }
            doc.setFontSize(14);
            doc.setTextColor(220, 53, 69);
            doc.text('Missing Skills:', 20, yPos);
            yPos += 10;
            doc.setFontSize(10);
            doc.setTextColor(0, 0, 0);
            currentResults.missingSkills.forEach((skill, index) => {
                if (yPos > 270) {
                    doc.addPage();
                    yPos = 20;
                }
                doc.text(`• ${skill}`, 25, yPos);
                yPos += 7;
            });
        }
        
        // Save
        const fileName = `Resume_JD_Match_${new Date().toISOString().split('T')[0]}.pdf`;
        doc.save(fileName);
        showError('PDF exported successfully!', 'success');
    } catch (error) {
        console.error('Error exporting PDF:', error);
        showError('Failed to export PDF. Please try again.', 'error');
    }
}

// Create Charts
function createCharts(results) {
    // Destroy existing charts
    if (scoreChart) {
        scoreChart.destroy();
    }
    if (skillsChart) {
        skillsChart.destroy();
    }
    
    // Score Breakdown Chart
    const scoreCtx = document.getElementById('scoreChart');
    if (scoreCtx) {
        scoreChart = new Chart(scoreCtx, {
            type: 'doughnut',
            data: {
                labels: ['Match Score', 'Remaining'],
                datasets: [{
                    data: [results.score, 100 - results.score],
                    backgroundColor: [
                        results.score >= 80 ? '#28a745' : results.score >= 60 ? '#ffc107' : '#dc3545',
                        '#e0e0e0'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    title: {
                        display: true,
                        text: 'Match Score Breakdown',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    }
                }
            }
        });
    }
    
    // Skills Comparison Chart
    const skillsCtx = document.getElementById('skillsChart');
    if (skillsCtx) {
        skillsChart = new Chart(skillsCtx, {
            type: 'bar',
            data: {
                labels: ['Matching', 'Missing', 'Total Resume', 'Total JD'],
                datasets: [{
                    label: 'Skills Count',
                    data: [
                        results.matchingSkills.length,
                        results.missingSkills.length,
                        results.resumeSkills.length,
                        results.jdSkills.length
                    ],
                    backgroundColor: [
                        '#28a745',
                        '#dc3545',
                        '#667eea',
                        '#ffc107'
                    ],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Skills Comparison',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    }
}

// Improved Error Display
function showError(message, type = 'error') {
    // Remove existing error messages
    const existingErrors = document.querySelectorAll('.error-message');
    existingErrors.forEach(err => err.remove());
    
    const errorDiv = document.createElement('div');
    errorDiv.className = `error-message ${type}`;
    
    const icons = {
        error: '❌',
        success: '✅',
        warning: '⚠️'
    };
    
    errorDiv.innerHTML = `
        <span class="error-icon">${icons[type] || 'ℹ️'}</span>
        <span class="error-text">${message}</span>
    `;
    
    // Insert after action section
    const actionSection = document.querySelector('.action-section');
    if (actionSection && actionSection.parentNode) {
        actionSection.parentNode.insertBefore(errorDiv, actionSection.nextSibling);
    }
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        errorDiv.style.animation = 'slideInDown 0.3s ease-out reverse';
        setTimeout(() => {
            errorDiv.remove();
        }, 300);
    }, 5000);
}

// Show notification message
function showNotification(message, type = 'info') {
    // Remove existing notification if any
    const existingNotification = document.querySelector('.file-notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `file-notification ${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        animation: slideInRight 0.3s ease-out;
        max-width: 400px;
    `;
    
    if (type === 'success') {
        notification.style.background = 'linear-gradient(135deg, #28a745 0%, #20c997 100%)';
    } else if (type === 'error') {
        notification.style.background = 'linear-gradient(135deg, #dc3545 0%, #c82333 100%)';
    } else {
        notification.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
    }
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    if (!document.querySelector('style[data-notification]')) {
        style.setAttribute('data-notification', 'true');
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.3s ease-out reverse';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 4000);
}

// Enhanced keyword extraction with better weighting
function extractKeywords(text) {
    const commonWords = new Set([
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
        'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
        'should', 'could', 'may', 'might', 'must', 'can', 'this', 'that',
        'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
        'work', 'experience', 'years', 'year', 'month', 'months', 'job',
        'position', 'role', 'company', 'responsibilities', 'duties'
    ]);

    // Technical keywords that should be weighted higher
    const technicalKeywords = new Set([
        'javascript', 'python', 'java', 'c++', 'sql', 'html', 'css', 'react',
        'angular', 'vue', 'node', 'express', 'django', 'flask', 'spring',
        'aws', 'azure', 'docker', 'kubernetes', 'git', 'github', 'agile',
        'scrum', 'api', 'rest', 'graphql', 'mongodb', 'postgresql', 'mysql',
        'machine learning', 'ai', 'data science', 'analytics', 'cloud'
    ]);

    // Convert to lowercase and split into words
    const words = text.toLowerCase()
        .replace(/[^\w\s]/g, ' ')
        .split(/\s+/)
        .filter(word => word.length > 2 && !commonWords.has(word));

    // Count word frequencies with weighting
    const wordFreq = {};
    words.forEach(word => {
        let weight = 1;
        // Increase weight for technical keywords
        if (technicalKeywords.has(word)) {
            weight = 2;
        }
        // Increase weight for longer words (likely technical terms)
        if (word.length > 6) {
            weight *= 1.5;
        }
        wordFreq[word] = (wordFreq[word] || 0) + weight;
    });

    // Also extract bigrams (two-word phrases) for better context
    const bigrams = [];
    for (let i = 0; i < words.length - 1; i++) {
        const bigram = `${words[i]} ${words[i + 1]}`;
        if (bigram.length > 5 && !commonWords.has(words[i]) && !commonWords.has(words[i + 1])) {
            bigrams.push(bigram);
        }
    }
    
    // Count bigram frequencies
    bigrams.forEach(bigram => {
        wordFreq[bigram] = (wordFreq[bigram] || 0) + 1.5;
    });

    // Return sorted keywords by weighted frequency
    return Object.entries(wordFreq)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 60)
        .map(entry => entry[0]);
}

// Extract skills (common technical and soft skills)
function extractSkills(text) {
    const skillKeywords = {
        // Technical Skills
        'javascript': ['javascript', 'js', 'node.js', 'react', 'vue', 'angular'],
        'python': ['python', 'django', 'flask', 'pandas', 'numpy'],
        'java': ['java', 'spring', 'hibernate', 'j2ee'],
        'c++': ['c++', 'cpp', 'c plus plus'],
        'sql': ['sql', 'mysql', 'postgresql', 'database', 'oracle'],
        'html': ['html', 'html5'],
        'css': ['css', 'css3', 'sass', 'scss', 'bootstrap'],
        'git': ['git', 'github', 'gitlab', 'version control'],
        'aws': ['aws', 'amazon web services', 'cloud'],
        'docker': ['docker', 'containerization'],
        'kubernetes': ['kubernetes', 'k8s'],
        'agile': ['agile', 'scrum', 'kanban'],
        'machine learning': ['machine learning', 'ml', 'deep learning', 'ai', 'artificial intelligence'],
        'data analysis': ['data analysis', 'analytics', 'data science'],
        // Soft Skills
        'communication': ['communication', 'communicate', 'verbal', 'written'],
        'leadership': ['leadership', 'lead', 'manage', 'management'],
        'teamwork': ['teamwork', 'collaboration', 'collaborate', 'team'],
        'problem solving': ['problem solving', 'problem-solving', 'analytical'],
        'project management': ['project management', 'pm', 'project manager']
    };

    const foundSkills = new Set();
    const lowerText = text.toLowerCase();

    for (const [skill, keywords] of Object.entries(skillKeywords)) {
        if (keywords.some(keyword => lowerText.includes(keyword))) {
            foundSkills.add(skill);
        }
    }

    return Array.from(foundSkills);
}

// Enhanced match score calculation with better weighting
function calculateMatchScore(resumeText, jdText) {
    const resumeKeywords = extractKeywords(resumeText);
    const jdKeywords = extractKeywords(jdText);
    const resumeSkills = extractSkills(resumeText);
    const jdSkills = extractSkills(jdText);

    // Calculate keyword overlap with fuzzy matching
    const matchingKeywords = [];
    const keywordScores = {};
    
    resumeKeywords.forEach(resumeKw => {
        jdKeywords.forEach(jdKw => {
            // Exact match
            if (resumeKw === jdKw) {
                matchingKeywords.push(resumeKw);
                keywordScores[resumeKw] = (keywordScores[resumeKw] || 0) + 2;
            }
            // Partial match (one contains the other)
            else if (resumeKw.includes(jdKw) || jdKw.includes(resumeKw)) {
                if (!matchingKeywords.includes(resumeKw)) {
                    matchingKeywords.push(resumeKw);
                }
                keywordScores[resumeKw] = (keywordScores[resumeKw] || 0) + 1;
            }
            // Similar words (Levenshtein distance)
            else if (calculateSimilarity(resumeKw, jdKw) > 0.8) {
                if (!matchingKeywords.includes(resumeKw)) {
                    matchingKeywords.push(resumeKw);
                }
                keywordScores[resumeKw] = (keywordScores[resumeKw] || 0) + 0.8;
            }
        });
    });

    const keywordOverlap = matchingKeywords.length;
    const keywordScore = jdKeywords.length > 0 
        ? Math.min((keywordOverlap / jdKeywords.length) * 50, 50)
        : 0;

    // Calculate skill overlap with importance weighting
    const matchingSkills = resumeSkills.filter(skill => jdSkills.includes(skill));
    const missingSkills = jdSkills.filter(skill => !resumeSkills.includes(skill));
    
    // Skills are more important than keywords
    const skillScore = jdSkills.length > 0 
        ? Math.min((matchingSkills.length / jdSkills.length) * 50, 50)
        : 0;

    // Bonus for having all required skills
    let bonus = 0;
    if (missingSkills.length === 0 && jdSkills.length > 0) {
        bonus = 5;
    }

    // Total score
    const totalScore = Math.round(keywordScore + skillScore + bonus);
    return {
        score: Math.min(totalScore, 100),
        matchingSkills,
        missingSkills,
        matchingKeywords: matchingKeywords.slice(0, 25),
        resumeSkills,
        jdSkills,
        keywordOverlap,
        totalKeywords: jdKeywords.length,
        resumeKeywordCount: resumeKeywords.length,
        jdKeywordCount: jdKeywords.length
    };
}

// Calculate similarity between two strings (Levenshtein distance)
function calculateSimilarity(str1, str2) {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) return 1.0;
    const distance = levenshteinDistance(longer, shorter);
    return (longer.length - distance) / longer.length;
}

function levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
        matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
        matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
        for (let j = 1; j <= str1.length; j++) {
            if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }
    return matrix[str2.length][str1.length];
}

// Display results
function displayResults(results) {
    // Store results for export
    currentResults = results;
    const resultsSection = document.getElementById('results-section');
    const loadingSection = document.getElementById('loading-section');
    const matchScore = document.getElementById('match-score');
    const scoreMessage = document.getElementById('score-message');
    const matchingSkills = document.getElementById('matching-skills');
    const missingSkills = document.getElementById('missing-skills');
    const matchingKeywordsContainer = document.getElementById('matching-keywords');
    const statistics = document.getElementById('statistics');
    const recommendations = document.getElementById('recommendations');
    
    // Update counts
    document.getElementById('matching-skills-count').textContent = results.matchingSkills.length;
    document.getElementById('missing-skills-count').textContent = results.missingSkills.length;
    document.getElementById('keywords-count').textContent = results.matchingKeywords.length;

    // Hide loading, show results
    loadingSection.classList.add('hidden');
    resultsSection.classList.remove('hidden');

    // Animate score counter
    animateScore(matchScore, results.score);

    // Update score message
    let message = '';
    if (results.score >= 80) {
        message = '🎉 Excellent match! You\'re a great fit for this position.';
    } else if (results.score >= 60) {
        message = '👍 Good match! Consider improving a few areas.';
    } else if (results.score >= 40) {
        message = '⚠️ Moderate match. Focus on developing missing skills.';
    } else {
        message = '📚 Needs improvement. Review recommendations below.';
    }
    scoreMessage.textContent = message;

    // Update score circle color based on score
    const scoreCircle = matchScore.parentElement;
    if (results.score >= 80) {
        scoreCircle.style.background = 'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)';
    } else if (results.score >= 60) {
        scoreCircle.style.background = 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)';
    } else {
        scoreCircle.style.background = 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)';
    }

    // Display matching skills
    matchingSkills.innerHTML = '';
    if (results.matchingSkills.length > 0) {
        results.matchingSkills.forEach((skill, index) => {
            const li = document.createElement('li');
            li.textContent = skill.charAt(0).toUpperCase() + skill.slice(1);
            li.style.animationDelay = `${index * 0.1}s`;
            matchingSkills.appendChild(li);
        });
    } else {
        matchingSkills.innerHTML = '<li style="color: #999; border-left-color: #999;">No matching skills found</li>';
    }

    // Display missing skills
    missingSkills.innerHTML = '';
    if (results.missingSkills.length > 0) {
        results.missingSkills.forEach((skill, index) => {
            const li = document.createElement('li');
            li.textContent = skill.charAt(0).toUpperCase() + skill.slice(1);
            li.style.borderLeftColor = '#dc3545';
            li.style.animationDelay = `${index * 0.1}s`;
            missingSkills.appendChild(li);
        });
    } else {
        missingSkills.innerHTML = '<li style="color: #28a745; border-left-color: #28a745;">✨ All required skills are present!</li>';
    }

    // Display matching keywords
    matchingKeywordsContainer.innerHTML = '';
    if (results.matchingKeywords.length > 0) {
        results.matchingKeywords.forEach((keyword, index) => {
            const tag = document.createElement('span');
            tag.className = 'keyword-tag';
            tag.textContent = keyword.charAt(0).toUpperCase() + keyword.slice(1);
            tag.style.animationDelay = `${index * 0.05}s`;
            matchingKeywordsContainer.appendChild(tag);
        });
    } else {
        matchingKeywordsContainer.innerHTML = '<p style="color: #999; text-align: center; padding: 20px;">No matching keywords found</p>';
    }

    // Display statistics
    statistics.innerHTML = `
        <div class="stat-item">
            <span class="stat-value">${results.keywordOverlap}</span>
            <span class="stat-label">Matching Keywords</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${results.totalKeywords}</span>
            <span class="stat-label">Total JD Keywords</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${results.resumeSkills.length}</span>
            <span class="stat-label">Resume Skills</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${results.jdSkills.length}</span>
            <span class="stat-label">Required Skills</span>
        </div>
    `;

    // Display recommendations
    recommendations.innerHTML = '';
    const recommendationList = generateRecommendations(results);
    recommendationList.forEach((rec, index) => {
        const item = document.createElement('div');
        item.className = 'recommendation-item';
        item.style.animationDelay = `${index * 0.1}s`;
        item.innerHTML = `
            <h4>${rec.icon} ${rec.title}</h4>
            <p>${rec.description}</p>
        `;
        recommendations.appendChild(item);
    });
    
    // Create charts
    setTimeout(() => {
        createCharts(results);
    }, 500);
}

// Animate score counter
function animateScore(element, targetScore) {
    let currentScore = 0;
    const increment = targetScore / 30;
    const timer = setInterval(() => {
        currentScore += increment;
        if (currentScore >= targetScore) {
            currentScore = targetScore;
            clearInterval(timer);
        }
        element.textContent = `${Math.round(currentScore)}%`;
    }, 30);
}

// Generate recommendations
function generateRecommendations(results) {
    const recommendations = [];

    if (results.score < 80) {
        if (results.missingSkills.length > 0) {
            recommendations.push({
                icon: '🎯',
                title: 'Focus on Missing Skills',
                description: `Prioritize learning or highlighting these skills: ${results.missingSkills.slice(0, 3).join(', ')}${results.missingSkills.length > 3 ? ', and more' : ''}. These are critical for this position.`
            });
        }

        if (results.keywordOverlap < results.totalKeywords * 0.5) {
            recommendations.push({
                icon: '📝',
                title: 'Improve Keyword Alignment',
                description: `Only ${results.keywordOverlap} out of ${results.totalKeywords} keywords match. Review the job description and incorporate relevant keywords naturally into your resume.`
            });
        }

        if (results.matchingSkills.length === 0) {
            recommendations.push({
                icon: '💼',
                title: 'Add Relevant Skills',
                description: 'Your resume doesn\'t match any required skills. Consider adding relevant technical and soft skills mentioned in the job description.'
            });
        }
    }

    if (results.score >= 60 && results.score < 80) {
        recommendations.push({
            icon: '✨',
            title: 'You\'re Almost There!',
            description: 'You have a solid foundation. Focus on the missing skills and keywords to increase your match score to 80% or higher.'
        });
    }

    if (results.missingSkills.length > 0 && results.matchingSkills.length > 0) {
        recommendations.push({
            icon: '🔄',
            title: 'Skill Development Plan',
            description: `You have ${results.matchingSkills.length} matching skills. Build on this strength while developing ${results.missingSkills.slice(0, 2).join(' and ')} to become a stronger candidate.`
        });
    }

    if (recommendations.length === 0) {
        recommendations.push({
            icon: '🎉',
            title: 'Excellent Match!',
            description: 'Your resume is well-aligned with the job description. You have most of the required skills and keywords. Keep up the great work!'
        });
    }

    return recommendations;
}

// Resume Management Functions
function getResumes() {
    try {
        const resumes = localStorage.getItem('savedResumes');
        return resumes ? JSON.parse(resumes) : [];
    } catch (error) {
        console.error('Error loading resumes:', error);
        return [];
    }
}

function saveResume(name, content, tags = []) {
    const resumes = getResumes();
    const resume = {
        id: editingResumeId || Date.now(),
        name: name.trim(),
        content: content.trim(),
        tags: Array.isArray(tags) ? tags : tags.split(',').map(t => t.trim()).filter(t => t),
        createdAt: editingResumeId ? resumes.find(r => r.id === editingResumeId)?.createdAt || new Date().toISOString() : new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    if (editingResumeId) {
        const index = resumes.findIndex(r => r.id === editingResumeId);
        if (index !== -1) {
            resumes[index] = resume;
        }
    } else {
        resumes.push(resume);
    }
    
    localStorage.setItem('savedResumes', JSON.stringify(resumes));
    return resume;
}

function deleteResume(id) {
    const resumes = getResumes();
    const filtered = resumes.filter(r => r.id !== id);
    localStorage.setItem('savedResumes', JSON.stringify(filtered));
}

function loadResumeSelect() {
    const resumes = getResumes();
    const select = document.getElementById('resume-select');
    if (!select) return;
    
    select.innerHTML = '<option value="">Select or create a resume...</option>';
    resumes.forEach(resume => {
        const option = document.createElement('option');
        option.value = resume.id;
        option.textContent = resume.name;
        select.appendChild(option);
    });
}

function loadResume(id) {
    const resumes = getResumes();
    const resume = resumes.find(r => r.id === parseInt(id));
    if (resume) {
        document.getElementById('resume-input').value = resume.content;
        currentResumeId = resume.id;
        document.getElementById('current-resume-name').textContent = `(${resume.name})`;
        document.getElementById('save-resume-btn').style.display = 'inline-block';
        showError(`Loaded resume: ${resume.name}`, 'success');
    }
}

function openResumeModal() {
    document.getElementById('resume-modal').classList.remove('hidden');
    loadResumeList();
}

function closeResumeModal() {
    document.getElementById('resume-modal').classList.add('hidden');
}

function loadResumeList() {
    const resumes = getResumes();
    const list = document.getElementById('resume-list');
    if (!list) return;
    
    list.innerHTML = '';
    if (resumes.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">No saved resumes. Click "Add New Resume" to create one.</p>';
        return;
    }
    
    resumes.forEach(resume => {
        const item = document.createElement('div');
        item.className = 'resume-item';
        item.innerHTML = `
            <div class="resume-item-name">${resume.name}</div>
            <div class="resume-item-tags">
                ${resume.tags.map(tag => `<span class="resume-tag">${tag}</span>`).join('')}
            </div>
            <div style="font-size: 0.85rem; color: #666; margin-top: 10px;">
                Updated: ${new Date(resume.updatedAt).toLocaleDateString()}
            </div>
            <div class="resume-item-actions">
                <button class="resume-action-btn load" onclick="loadResumeFromModal(${resume.id})">Load</button>
                <button class="resume-action-btn edit" onclick="editResume(${resume.id})">Edit</button>
                <button class="resume-action-btn delete" onclick="deleteResumeFromModal(${resume.id})">Delete</button>
            </div>
        `;
        list.appendChild(item);
    });
}

function loadResumeFromModal(id) {
    loadResume(id);
    closeResumeModal();
}

function deleteResumeFromModal(id) {
    if (confirm('Are you sure you want to delete this resume?')) {
        deleteResume(id);
        loadResumeList();
        loadResumeSelect();
        showError('Resume deleted!', 'success');
    }
}

function editResume(id) {
    const resumes = getResumes();
    const resume = resumes.find(r => r.id === id);
    if (resume) {
        editingResumeId = id;
        document.getElementById('resume-name-input').value = resume.name;
        document.getElementById('resume-content-input').value = resume.content;
        document.getElementById('resume-tags-input').value = resume.tags.join(', ');
        document.getElementById('add-resume-title').textContent = 'Edit Resume';
        document.getElementById('resume-modal').classList.add('hidden');
        document.getElementById('add-resume-modal').classList.remove('hidden');
    }
}

function openAddResumeModal() {
    editingResumeId = null;
    document.getElementById('resume-name-input').value = '';
    document.getElementById('resume-content-input').value = '';
    document.getElementById('resume-tags-input').value = '';
    document.getElementById('add-resume-title').textContent = 'Add New Resume';
    document.getElementById('add-resume-modal').classList.remove('hidden');
}

function closeAddResumeModal() {
    document.getElementById('add-resume-modal').classList.add('hidden');
    editingResumeId = null;
}

function saveResumeFromModal() {
    const name = document.getElementById('resume-name-input').value.trim();
    const content = document.getElementById('resume-content-input').value.trim();
    const tags = document.getElementById('resume-tags-input').value.trim();
    
    if (!name || !content) {
        showError('Please fill in both name and content fields.', 'warning');
        return;
    }
    
    saveResume(name, content, tags);
    loadResumeSelect();
    closeAddResumeModal();
    showError(editingResumeId ? 'Resume updated!' : 'Resume saved!', 'success');
}

function saveCurrentResume() {
    const content = document.getElementById('resume-input').value.trim();
    if (!content) {
        showError('No resume content to save.', 'warning');
        return;
    }
    
    if (!currentResumeId) {
        const name = prompt('Enter a name for this resume:');
        if (!name) return;
        const resume = saveResume(name, content);
        currentResumeId = resume.id;
        loadResumeSelect();
        document.getElementById('resume-select').value = resume.id;
        document.getElementById('current-resume-name').textContent = `(${resume.name})`;
        document.getElementById('save-resume-btn').style.display = 'inline-block';
    } else {
        const resumes = getResumes();
        const resume = resumes.find(r => r.id === currentResumeId);
        if (resume) {
            saveResume(resume.name, content, resume.tags);
            showError('Resume updated!', 'success');
        }
    }
}

// ATS Optimization Functions (uses backend /api/ats-check when available, falls back to local)
function performATSCheck() {
    const atsSection = document.getElementById('ats-section');
    const atsCheckBtn = document.getElementById('ats-check-btn');
    
    // Toggle ATS section if it's already visible
    if (!atsSection.classList.contains('hidden')) {
        closeATSSection();
        return;
    }
    
    const resumeText = document.getElementById('resume-input').value.trim();
    if (!resumeText) {
        showError('Please enter resume content first.', 'warning');
        return;
    }

    // Try backend ATS check first
    fetch(`${API_BASE_URL}/ats-check`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ resume_text: resumeText })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Backend error: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        // Backend returns { overall_score, checks }
        displayATSResults({
            overallScore: data.overall_score ?? data.overallScore ?? 0,
            checks: data.checks || []
        });
        atsSection.classList.remove('hidden');
        if (atsCheckBtn) {
            const btnText = atsCheckBtn.querySelector('span');
            if (btnText) {
                btnText.textContent = '🔍 Hide ATS Report';
            }
        }
        atsSection.scrollIntoView({ behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error calling backend /api/ats-check, using local ATS:', error);
        showError('Backend ATS not available, using local ATS.', 'warning');
        const atsResults = analyzeATS(resumeText);
        displayATSResults(atsResults);
        atsSection.classList.remove('hidden');
        if (atsCheckBtn) {
            const btnText = atsCheckBtn.querySelector('span');
            if (btnText) {
                btnText.textContent = '🔍 Hide ATS Report';
            }
        }
        atsSection.scrollIntoView({ behavior: 'smooth' });
    });
}

function closeATSSection() {
    const atsSection = document.getElementById('ats-section');
    atsSection.classList.add('hidden');
    // Update button text if needed
    const atsCheckBtn = document.getElementById('ats-check-btn');
    if (atsCheckBtn) {
        const btnText = atsCheckBtn.querySelector('span');
        if (btnText) {
            btnText.textContent = '🔍 ATS Check';
        }
    }
}

function analyzeATS(resumeText) {
    const results = {
        overallScore: 0,
        checks: []
    };
    
    let passedChecks = 0;
    const totalChecks = 10;
    
    // Check 1: Length
    const wordCount = resumeText.split(/\s+/).length;
    const lengthCheck = {
        title: 'Resume Length',
        status: wordCount >= 400 && wordCount <= 800 ? 'pass' : wordCount < 400 ? 'warning' : 'fail',
        description: `Your resume has ${wordCount} words.`,
        suggestions: wordCount < 400 
            ? ['Add more details about your experience and achievements', 'Include specific metrics and accomplishments']
            : wordCount > 800 
            ? ['Consider condensing your resume to 1-2 pages', 'Remove outdated or less relevant information']
            : ['Good length for most positions']
    };
    if (lengthCheck.status === 'pass') passedChecks++;
    results.checks.push(lengthCheck);
    
    // Check 2: Contact Information
    const hasEmail = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/.test(resumeText);
    const hasPhone = /(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/.test(resumeText);
    const contactCheck = {
        title: 'Contact Information',
        status: hasEmail && hasPhone ? 'pass' : 'fail',
        description: hasEmail && hasPhone 
            ? 'Email and phone number found.'
            : `Missing: ${!hasEmail ? 'Email' : ''} ${!hasPhone ? 'Phone' : ''}`,
        suggestions: !hasEmail || !hasPhone 
            ? ['Add a professional email address', 'Include a phone number']
            : []
    };
    if (contactCheck.status === 'pass') passedChecks++;
    results.checks.push(contactCheck);
    
    // Check 3: Keywords
    const keywordDensity = extractKeywords(resumeText).length;
    const keywordCheck = {
        title: 'Keyword Density',
        status: keywordDensity >= 20 ? 'pass' : keywordDensity >= 10 ? 'warning' : 'fail',
        description: `Found ${keywordDensity} relevant keywords.`,
        suggestions: keywordDensity < 20 
            ? ['Include more industry-specific keywords', 'Add technical skills and tools you\'ve used']
            : []
    };
    if (keywordCheck.status === 'pass') passedChecks++;
    results.checks.push(keywordCheck);
    
    // Check 4: Action Verbs
    const actionVerbs = ['developed', 'created', 'implemented', 'managed', 'led', 'designed', 'built', 'improved', 'optimized', 'achieved'];
    const hasActionVerbs = actionVerbs.some(verb => resumeText.toLowerCase().includes(verb));
    const actionVerbCheck = {
        title: 'Action Verbs',
        status: hasActionVerbs ? 'pass' : 'warning',
        description: hasActionVerbs ? 'Good use of action verbs found.' : 'Limited use of action verbs.',
        suggestions: !hasActionVerbs 
            ? ['Start bullet points with action verbs', 'Use words like: developed, created, implemented, managed, led']
            : []
    };
    if (actionVerbCheck.status === 'pass') passedChecks++;
    results.checks.push(actionVerbCheck);
    
    // Check 5: Quantifiable Achievements
    const hasNumbers = /\d+/.test(resumeText);
    const quantifiableCheck = {
        title: 'Quantifiable Achievements',
        status: hasNumbers ? 'pass' : 'warning',
        description: hasNumbers ? 'Numbers and metrics found.' : 'Limited use of numbers and metrics.',
        suggestions: !hasNumbers 
            ? ['Add specific numbers (percentages, dollar amounts, timeframes)', 'Include metrics like: "increased sales by 25%" or "managed team of 10"']
            : []
    };
    if (quantifiableCheck.status === 'pass') passedChecks++;
    results.checks.push(quantifiableCheck);
    
    // Check 6: File Format (simulated - we can't check actual file format)
    const formatCheck = {
        title: 'File Format Compatibility',
        status: 'warning',
        description: 'Ensure your resume is saved as .docx or .pdf for best ATS compatibility.',
        suggestions: ['Avoid .doc (old format)', 'PDF is preferred for most ATS systems', 'Avoid images and complex formatting']
    };
    passedChecks += 0.5; // Half point
    results.checks.push(formatCheck);
    
    // Check 7: Skills Section
    const skillsKeywords = ['skills', 'technical skills', 'competencies', 'expertise'];
    const hasSkillsSection = skillsKeywords.some(keyword => resumeText.toLowerCase().includes(keyword));
    const skillsSectionCheck = {
        title: 'Skills Section',
        status: hasSkillsSection ? 'pass' : 'warning',
        description: hasSkillsSection ? 'Skills section found.' : 'No clear skills section identified.',
        suggestions: !hasSkillsSection 
            ? ['Add a dedicated skills section', 'List technical and soft skills clearly']
            : []
    };
    if (skillsSectionCheck.status === 'pass') passedChecks++;
    results.checks.push(skillsSectionCheck);
    
    // Check 8: Education
    const educationKeywords = ['education', 'university', 'college', 'degree', 'bachelor', 'master', 'phd'];
    const hasEducation = educationKeywords.some(keyword => resumeText.toLowerCase().includes(keyword));
    const educationCheck = {
        title: 'Education Section',
        status: hasEducation ? 'pass' : 'warning',
        description: hasEducation ? 'Education information found.' : 'Education section may be missing.',
        suggestions: !hasEducation 
            ? ['Include your educational background', 'List degrees, institutions, and graduation dates']
            : []
    };
    if (educationCheck.status === 'pass') passedChecks++;
    results.checks.push(educationCheck);
    
    // Check 9: Experience Section
    const experienceKeywords = ['experience', 'work', 'employment', 'position', 'role', 'job'];
    const hasExperience = experienceKeywords.some(keyword => resumeText.toLowerCase().includes(keyword));
    const experienceCheck = {
        title: 'Work Experience',
        status: hasExperience ? 'pass' : 'fail',
        description: hasExperience ? 'Work experience section found.' : 'Work experience section may be missing.',
        suggestions: !hasExperience 
            ? ['Include a work experience section', 'List companies, positions, dates, and responsibilities']
            : []
    };
    if (experienceCheck.status === 'pass') passedChecks++;
    results.checks.push(experienceCheck);
    
    // Check 10: Professional Summary
    const summaryKeywords = ['summary', 'objective', 'profile', 'about'];
    const hasSummary = summaryKeywords.some(keyword => resumeText.toLowerCase().includes(keyword));
    const summaryCheck = {
        title: 'Professional Summary',
        status: hasSummary ? 'pass' : 'warning',
        description: hasSummary ? 'Professional summary found.' : 'Consider adding a professional summary.',
        suggestions: !hasSummary 
            ? ['Add a 2-3 sentence professional summary at the top', 'Highlight your key qualifications and career goals']
            : []
    };
    if (summaryCheck.status === 'pass') passedChecks++;
    results.checks.push(summaryCheck);
    
    results.overallScore = Math.round((passedChecks / totalChecks) * 100);
    return results;
}

function displayATSResults(results) {
    const container = document.getElementById('ats-results');
    container.innerHTML = `
        <div class="ats-item" style="margin-bottom: 20px; background: linear-gradient(135deg, #f8f9ff 0%, #f0f2ff 100%);">
            <div class="ats-item-header">
                <span class="ats-item-title">Overall ATS Score</span>
                <span class="ats-item-status ${results.overallScore >= 80 ? 'pass' : results.overallScore >= 60 ? 'warning' : 'fail'}">
                    ${results.overallScore}%
                </span>
            </div>
            <div class="ats-item-description">
                ${results.overallScore >= 80 
                    ? 'Excellent! Your resume is well-optimized for ATS systems.' 
                    : results.overallScore >= 60 
                    ? 'Good, but there\'s room for improvement.' 
                    : 'Your resume needs significant improvements for ATS compatibility.'}
            </div>
        </div>
    `;
    
    results.checks.forEach(check => {
        const item = document.createElement('div');
        item.className = `ats-item ${check.status}`;
        item.innerHTML = `
            <div class="ats-item-header">
                <span class="ats-item-title">${check.title}</span>
                <span class="ats-item-status ${check.status}">
                    ${check.status === 'pass' ? '✓ Pass' : check.status === 'warning' ? '⚠ Warning' : '✗ Fail'}
                </span>
            </div>
            <div class="ats-item-description">${check.description}</div>
            ${check.suggestions.length > 0 ? `
                <div class="ats-suggestions">
                    <div class="ats-suggestions-title">💡 Suggestions:</div>
                    ${check.suggestions.map(s => `<div class="ats-suggestion-item">• ${s}</div>`).join('')}
                </div>
            ` : ''}
        `;
        container.appendChild(item);
    });
}

// Page Navigation Functions
function showPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.remove('active');
        page.classList.add('hidden');
    });
    
    // Show target page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.remove('hidden');
        targetPage.classList.add('active');
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Page navigation elements
    const startBtn = document.getElementById('start-btn');
    const backBtn = document.getElementById('back-btn');
    const landingPage = document.getElementById('landing-page');
    const uploadPage = document.getElementById('upload-page');
    
    // Navigation handlers
    if (startBtn) {
        startBtn.addEventListener('click', () => {
            showPage('upload-page');
        });
    }
    
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            showPage('landing-page');
            // Clear results when going back
            document.getElementById('results-section').classList.add('hidden');
            document.getElementById('loading-section').classList.add('hidden');
        });
    }
    
    const resumeFileInput = document.getElementById('resume-file');
    const jdFileInput = document.getElementById('jd-file');
    const matchBtn = document.getElementById('match-btn');
    const clearBtn = document.getElementById('clear-btn');
    const resumeInput = document.getElementById('resume-input');
    const jdInput = document.getElementById('jd-input');

    // File upload handlers
    resumeFileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileUpload(e.target.files[0], 'resume-input', 'resume-file-name');
        }
    });

    jdFileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileUpload(e.target.files[0], 'jd-input', 'jd-file-name');
        }
    });

    // Match button handler (uses backend /api/match when available, falls back to local)
    matchBtn.addEventListener('click', async () => {
        const resumeText = resumeInput.value.trim();
        const jdText = jdInput.value.trim();

        if (!resumeText || !jdText) {
            showError('Please enter both resume content and job description!', 'warning');
            return;
        }

        if (resumeText.length < 50 || jdText.length < 50) {
            showError('Please provide more detailed content (at least 50 characters each).', 'warning');
            return;
        }

        // Show loading
        const loadingSection = document.getElementById('loading-section');
        const resultsSection = document.getElementById('results-section');
        loadingSection.classList.remove('hidden');
        resultsSection.classList.add('hidden');

        let results = null;

        // Try backend API first
        try {
            const response = await fetch(`${API_BASE_URL}/match`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    resume_text: resumeText,
                    jd_text: jdText
                })
            });

            if (!response.ok) {
                throw new Error(`Backend error: ${response.status}`);
            }

            const data = await response.json();
            if (data.error) {
                throw new Error(data.error);
            }

            // Map backend response to frontend result shape
            results = {
                score: data.score,
                matchingSkills: data.matching_skills || data.matchingSkills || [],
                missingSkills: data.missing_skills || data.missingSkills || [],
                matchingKeywords: data.matching_keywords || data.matchingKeywords || [],
                resumeSkills: data.resume_skills || data.resumeSkills || [],
                jdSkills: data.jd_skills || data.jdSkills || [],
                keywordOverlap: data.keyword_overlap ?? data.keywordOverlap ?? 0,
                totalKeywords: data.total_keywords ?? data.totalKeywords ?? 0,
                resumeKeywordCount: data.resume_keyword_count ?? data.resumeKeywordCount ?? 0,
                jdKeywordCount: data.jd_keyword_count ?? data.jdKeywordCount ?? 0
            };
        } catch (error) {
            console.error('Error calling backend /api/match, falling back to local:', error);
            showError('Backend not available, using local matching.', 'warning');
            // Fallback: use client-side matching
            results = calculateMatchScore(resumeText, jdText);
        }

        // Display results
        displayResults(results);

        // Scroll to results
        setTimeout(() => {
            document.getElementById('results-section').scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
            });
        }, 100);
    });

    // Clear button handler
    clearBtn.addEventListener('click', () => {
        resumeInput.value = '';
        jdInput.value = '';
        resumeFileInput.value = '';
        jdFileInput.value = '';
        const resumeFileName = document.getElementById('resume-file-name');
        const jdFileName = document.getElementById('jd-file-name');
        resumeFileName.classList.remove('show');
        resumeFileName.textContent = '';
        resumeFileName.style.color = '';
        jdFileName.classList.remove('show');
        jdFileName.textContent = '';
        jdFileName.style.color = '';
        document.getElementById('results-section').classList.add('hidden');
        document.getElementById('loading-section').classList.add('hidden');
        currentResults = null;
        if (scoreChart) scoreChart.destroy();
        if (skillsChart) skillsChart.destroy();
    });
    
    // Save to history button
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            const resumeText = resumeInput.value.trim();
            const jdText = jdInput.value.trim();
            
            if (!resumeText || !jdText) {
                showError('Please enter both resume and job description before saving.', 'warning');
                return;
            }
            
            if (!currentResults) {
                showError('Please run a match first before saving to history.', 'warning');
                return;
            }
            
            saveToHistory(resumeText, jdText, currentResults);
        });
    }
    
    // Export PDF button
    const exportPdfBtn = document.getElementById('export-pdf-btn');
    if (exportPdfBtn) {
        exportPdfBtn.addEventListener('click', exportToPDF);
    }
    
    // Clear history button
    const clearHistoryBtn = document.getElementById('clear-history-btn');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', clearAllHistory);
    }
    
    // Load history on page load
    loadHistory();
    
    // Resume Management Event Listeners
    const manageResumesBtn = document.getElementById('manage-resumes-btn');
    const newResumeBtn = document.getElementById('new-resume-btn');
    const resumeSelect = document.getElementById('resume-select');
    const saveResumeBtn = document.getElementById('save-resume-btn');
    const closeModal = document.getElementById('close-modal');
    const closeAddModal = document.getElementById('close-add-modal');
    const addResumeBtn = document.getElementById('add-resume-btn');
    const saveResumeModalBtn = document.getElementById('save-resume-modal-btn');
    const cancelResumeBtn = document.getElementById('cancel-resume-btn');
    
    if (manageResumesBtn) {
        manageResumesBtn.addEventListener('click', openResumeModal);
    }
    
    if (newResumeBtn) {
        newResumeBtn.addEventListener('click', openAddResumeModal);
    }
    
    if (resumeSelect) {
        resumeSelect.addEventListener('change', (e) => {
            if (e.target.value) {
                loadResume(e.target.value);
            } else {
                currentResumeId = null;
                document.getElementById('current-resume-name').textContent = '';
                document.getElementById('save-resume-btn').style.display = 'none';
            }
        });
    }
    
    if (saveResumeBtn) {
        saveResumeBtn.addEventListener('click', saveCurrentResume);
    }
    
    if (closeModal) {
        closeModal.addEventListener('click', closeResumeModal);
    }
    
    if (closeAddModal) {
        closeAddModal.addEventListener('click', closeAddResumeModal);
    }
    
    if (addResumeBtn) {
        addResumeBtn.addEventListener('click', openAddResumeModal);
    }
    
    if (saveResumeModalBtn) {
        saveResumeModalBtn.addEventListener('click', saveResumeFromModal);
    }
    
    if (cancelResumeBtn) {
        cancelResumeBtn.addEventListener('click', closeAddResumeModal);
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', (e) => {
        const resumeModal = document.getElementById('resume-modal');
        const addResumeModal = document.getElementById('add-resume-modal');
        if (e.target === resumeModal) {
            closeResumeModal();
        }
        if (e.target === addResumeModal) {
            closeAddResumeModal();
        }
    });
    
    // ATS Check Button
    const atsCheckBtn = document.getElementById('ats-check-btn');
    if (atsCheckBtn) {
        atsCheckBtn.addEventListener('click', performATSCheck);
    }
    
    // Close ATS Button
    const closeAtsBtn = document.getElementById('close-ats-btn');
    if (closeAtsBtn) {
        closeAtsBtn.addEventListener('click', closeATSSection);
    }
    
    // Load resumes on page load
    loadResumeSelect();
    
    // Make functions global for onclick handlers
    window.loadFromHistory = loadFromHistory;
    window.deleteFromHistory = deleteFromHistory;
    window.loadResumeFromModal = loadResumeFromModal;
    window.deleteResumeFromModal = deleteResumeFromModal;
    window.editResume = editResume;
});

