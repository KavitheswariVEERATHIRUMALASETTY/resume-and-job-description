from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS
import os
import json
import traceback
from datetime import datetime
from database import init_db, db_session, get_db
from models import Resume, JobDescription, MatchResult, ResumeHistory
from nlp_processor import NLPProcessor
from matching_engine import MatchingEngine

app = Flask(__name__, static_folder='../', static_url_path='')
CORS(app)  # Enable CORS for frontend

# Initialize database
if not init_db():
    print("Warning: Database initialization failed. Some features may not work.")

# Initialize NLP processor
try:
    nlp_processor = NLPProcessor()
    print("✓ NLP Processor initialized")
except Exception as e:
    print(f"⚠ Warning: NLP Processor initialization failed: {e}")
    nlp_processor = None

# Initialize matching engine
if nlp_processor:
    matching_engine = MatchingEngine(nlp_processor)
    print("✓ Matching Engine initialized")
else:
    matching_engine = None
    print("⚠ Warning: Matching Engine not initialized")

@app.before_request
def before_request():
    """Set up database session for each request"""
    g.db = get_db()

@app.teardown_appcontext
def close_db(error):
    """Close database session after each request"""
    db_session.remove()

@app.route('/')
def index():
    """Serve the frontend"""
    return send_from_directory('../', 'index.html')

@app.route('/api/match', methods=['POST'])
def match_resume_jd():
    """Match resume with job description"""
    try:
        data = request.json
        resume_text = data.get('resume_text', '').strip()
        jd_text = data.get('jd_text', '').strip()
        
        if not resume_text or not jd_text:
            return jsonify({
                'error': 'Both resume_text and jd_text are required'
            }), 400
        
        # Check if NLP processor is available
        if not nlp_processor or not matching_engine:
            return jsonify({
                'error': 'NLP processor not initialized. Please check backend setup.'
            }), 500
        
        # Process with NLP
        resume_processed = nlp_processor.process_text(resume_text)
        jd_processed = nlp_processor.process_text(jd_text)
        
        # Calculate match score
        match_result = matching_engine.calculate_match(
            resume_processed, 
            jd_processed,
            resume_text,
            jd_text
        )
        
        # Save to database
        try:
            match_record = MatchResult(
                resume_text=resume_text[:500],  # Store preview
                jd_text=jd_text[:500],
                match_score=match_result['score'],
                matching_skills=json.dumps(match_result['matching_skills']),
                missing_skills=json.dumps(match_result['missing_skills']),
                matching_keywords=json.dumps(match_result['matching_keywords']),
                resume_keyword_count=match_result.get('resume_keyword_count', 0),
                jd_keyword_count=match_result.get('jd_keyword_count', 0),
                keyword_overlap=match_result.get('keyword_overlap', 0),
                created_at=datetime.now()
            )
            db_session.add(match_record)
            db_session.commit()
            match_result['match_id'] = match_record.id
        except Exception as db_error:
            db_session.rollback()
            print(f"Database error: {db_error}")
            # Still return the match result even if saving fails
        
        return jsonify(match_result), 200
        
    except Exception as e:
        db_session.rollback()
        print(f"Error in match_resume_jd: {traceback.format_exc()}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/ats-check', methods=['POST'])
def ats_check():
    """Perform ATS optimization check on resume"""
    try:
        data = request.json
        resume_text = data.get('resume_text', '').strip()
        
        if not resume_text:
            return jsonify({
                'error': 'resume_text is required'
            }), 400
        
        # Perform ATS analysis
        ats_result = nlp_processor.analyze_ats(resume_text)
        
        return jsonify(ats_result), 200
        
    except Exception as e:
        print(f"Error in ats_check: {traceback.format_exc()}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get match history"""
    try:
        limit = request.args.get('limit', 20, type=int)
        history = db_session.query(MatchResult).order_by(
            MatchResult.created_at.desc()
        ).limit(limit).all()
        
        history_list = []
        for item in history:
            try:
                history_list.append({
                    'id': item.id,
                    'resume_preview': item.resume_text or '',
                    'jd_preview': item.jd_text or '',
                    'score': float(item.match_score),
                    'date': item.created_at.isoformat() if item.created_at else datetime.now().isoformat(),
                    'matching_skills': json.loads(item.matching_skills) if item.matching_skills else [],
                    'missing_skills': json.loads(item.missing_skills) if item.missing_skills else []
                })
            except Exception as e:
                print(f"Error processing history item {item.id}: {e}")
                continue
        
        return jsonify({'history': history_list}), 200
        
    except Exception as e:
        print(f"Error in get_history: {traceback.format_exc()}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/history/<int:history_id>', methods=['GET'])
def get_history_item(history_id):
    """Get specific history item"""
    try:
        item = db_session.query(MatchResult).filter_by(id=history_id).first()
        
        if not item:
            return jsonify({'error': 'History item not found'}), 404
        
        return jsonify({
            'id': item.id,
            'resume_text': item.resume_text,
            'jd_text': item.jd_text,
            'score': item.match_score,
            'date': item.created_at.isoformat(),
            'matching_skills': json.loads(item.matching_skills) if item.matching_skills else [],
            'missing_skills': json.loads(item.missing_skills) if item.missing_skills else [],
            'matching_keywords': json.loads(item.matching_keywords) if item.matching_keywords else []
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/history/<int:history_id>', methods=['DELETE'])
def delete_history_item(history_id):
    """Delete a history item"""
    try:
        item = db_session.query(MatchResult).filter_by(id=history_id).first()
        
        if not item:
            return jsonify({'error': 'History item not found'}), 404
        
        db_session.delete(item)
        db_session.commit()
        
        return jsonify({'message': 'History item deleted successfully'}), 200
        
    except Exception as e:
        db_session.rollback()
        print(f"Error in delete_history_item: {traceback.format_exc()}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/history', methods=['DELETE'])
def clear_all_history():
    """Clear all history"""
    try:
        db_session.query(MatchResult).delete()
        db_session.commit()
        
        return jsonify({'message': 'All history cleared successfully'}), 200
        
    except Exception as e:
        db_session.rollback()
        print(f"Error in clear_all_history: {traceback.format_exc()}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/resumes', methods=['POST'])
def save_resume():
    """Save a resume"""
    try:
        data = request.json
        name = data.get('name', '').strip()
        content = data.get('content', '').strip()
        tags = data.get('tags', [])
        
        if not name or not content:
            return jsonify({
                'error': 'Both name and content are required'
            }), 400
        
        resume = Resume(
            name=name,
            content=content,
            tags=json.dumps(tags) if isinstance(tags, list) else tags,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        db_session.add(resume)
        db_session.commit()
        
        return jsonify({
            'id': resume.id,
            'name': resume.name,
            'message': 'Resume saved successfully'
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/resumes', methods=['GET'])
def get_resumes():
    """Get all saved resumes"""
    try:
        resumes = db_session.query(Resume).order_by(
            Resume.updated_at.desc()
        ).all()
        
        resume_list = []
        for resume in resumes:
            resume_list.append({
                'id': resume.id,
                'name': resume.name,
                'content': resume.content,
                'tags': json.loads(resume.tags) if resume.tags else [],
                'created_at': resume.created_at.isoformat(),
                'updated_at': resume.updated_at.isoformat()
            })
        
        return jsonify({'resumes': resume_list}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/resumes/<int:resume_id>', methods=['GET'])
def get_resume(resume_id):
    """Get a specific resume"""
    try:
        resume = db_session.query(Resume).filter_by(id=resume_id).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        return jsonify({
            'id': resume.id,
            'name': resume.name,
            'content': resume.content,
            'tags': json.loads(resume.tags) if resume.tags else [],
            'created_at': resume.created_at.isoformat(),
            'updated_at': resume.updated_at.isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/resumes/<int:resume_id>', methods=['PUT'])
def update_resume(resume_id):
    """Update a resume"""
    try:
        resume = db_session.query(Resume).filter_by(id=resume_id).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        data = request.json
        if 'name' in data:
            resume.name = data['name'].strip()
        if 'content' in data:
            resume.content = data['content'].strip()
        if 'tags' in data:
            resume.tags = json.dumps(data['tags']) if isinstance(data['tags'], list) else data['tags']
        
        resume.updated_at = datetime.now()
        db_session.commit()
        
        return jsonify({
            'id': resume.id,
            'message': 'Resume updated successfully'
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/resumes/<int:resume_id>', methods=['DELETE'])
def delete_resume(resume_id):
    """Delete a resume"""
    try:
        resume = db_session.query(Resume).filter_by(id=resume_id).first()
        
        if not resume:
            return jsonify({'error': 'Resume not found'}), 404
        
        db_session.delete(resume)
        db_session.commit()
        
        return jsonify({'message': 'Resume deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    db_session.rollback()
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("=" * 50)
    print("Resume JD Matcher Backend Server")
    print("=" * 50)
    print(f"Server starting on http://0.0.0.0:5000")
    print(f"Database: {os.path.join(os.path.dirname(__file__), 'resume_matcher.db')}")
    print("=" * 50)
    app.run(debug=True, host='0.0.0.0', port=5000)

