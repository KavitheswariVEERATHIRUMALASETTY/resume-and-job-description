from difflib import SequenceMatcher

class MatchingEngine:
    """Advanced matching engine for resume and JD comparison"""
    
    def __init__(self, nlp_processor):
        self.nlp_processor = nlp_processor
    
    def calculate_match(self, resume_processed, jd_processed, resume_text, jd_text):
        """Calculate match score between resume and JD"""
        
        # Extract features
        resume_keywords = resume_processed['keywords']
        jd_keywords = jd_processed['keywords']
        resume_skills = resume_processed['skills']
        jd_skills = jd_processed['skills']
        resume_bigrams = resume_processed['bigrams']
        jd_bigrams = jd_processed['bigrams']
        
        # Calculate keyword overlap with fuzzy matching
        matching_keywords = self._find_matching_keywords(resume_keywords, jd_keywords)
        keyword_overlap = len(matching_keywords)
        
        # Calculate keyword score (50% weight)
        keyword_score = 0
        if jd_keywords:
            keyword_score = min((keyword_overlap / len(jd_keywords)) * 50, 50)
        
        # Calculate skill overlap
        matching_skills = [skill for skill in resume_skills if skill in jd_skills]
        missing_skills = [skill for skill in jd_skills if skill not in resume_skills]
        
        # Skills are more important (50% weight)
        skill_score = 0
        if jd_skills:
            skill_score = min((len(matching_skills) / len(jd_skills)) * 50, 50)
        
        # Calculate bigram overlap (bonus)
        matching_bigrams = self._find_matching_bigrams(resume_bigrams, jd_bigrams)
        bigram_bonus = min(len(matching_bigrams) * 2, 5)  # Max 5% bonus
        
        # Bonus for having all required skills
        completion_bonus = 0
        if missing_skills == [] and jd_skills:
            completion_bonus = 5
        
        # Total score
        total_score = round(keyword_score + skill_score + bigram_bonus + completion_bonus)
        
        return {
            'score': min(total_score, 100),
            'matching_skills': matching_skills,
            'missing_skills': missing_skills,
            'matching_keywords': matching_keywords[:25],
            'resume_skills': resume_skills,
            'jd_skills': jd_skills,
            'keyword_overlap': keyword_overlap,
            'total_keywords': len(jd_keywords),
            'resume_keyword_count': len(resume_keywords),
            'jd_keyword_count': len(jd_keywords),
            'matching_bigrams': matching_bigrams[:10]
        }
    
    def _find_matching_keywords(self, resume_keywords, jd_keywords):
        """Find matching keywords with fuzzy matching"""
        matching = []
        used_jd_keywords = set()
        
        for resume_kw in resume_keywords:
            best_match = None
            best_similarity = 0
            
            for jd_kw in jd_keywords:
                if jd_kw in used_jd_keywords:
                    continue
                
                # Exact match
                if resume_kw == jd_kw:
                    best_match = resume_kw
                    best_similarity = 1.0
                    break
                
                # Partial match (one contains the other)
                elif resume_kw in jd_kw or jd_kw in resume_kw:
                    similarity = len(resume_kw) / max(len(resume_kw), len(jd_kw))
                    if similarity > best_similarity:
                        best_match = resume_kw
                        best_similarity = similarity
                
                # Fuzzy match using sequence matcher
                else:
                    similarity = SequenceMatcher(None, resume_kw, jd_kw).ratio()
                    if similarity > 0.8 and similarity > best_similarity:
                        best_match = resume_kw
                        best_similarity = similarity
            
            if best_match and best_similarity > 0.7:
                matching.append(best_match)
                # Mark JD keyword as used
                for jd_kw in jd_keywords:
                    if (jd_kw == best_match or 
                        best_match in jd_kw or 
                        jd_kw in best_match or
                        SequenceMatcher(None, best_match, jd_kw).ratio() > 0.8):
                        used_jd_keywords.add(jd_kw)
                        break
        
        return matching
    
    def _find_matching_bigrams(self, resume_bigrams, jd_bigrams):
        """Find matching bigrams"""
        matching = []
        resume_bigrams_lower = [bg.lower() for bg in resume_bigrams]
        jd_bigrams_lower = [bg.lower() for bg in jd_bigrams]
        
        for resume_bg in resume_bigrams_lower:
            for jd_bg in jd_bigrams_lower:
                # Exact match
                if resume_bg == jd_bg:
                    if resume_bg not in matching:
                        matching.append(resume_bg)
                # Partial match
                elif resume_bg in jd_bg or jd_bg in resume_bg:
                    if resume_bg not in matching:
                        matching.append(resume_bg)
        
        return matching

