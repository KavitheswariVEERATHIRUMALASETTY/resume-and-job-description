import re
import json
from collections import Counter
try:
    import spacy
    SPACY_AVAILABLE = True
except ImportError:
    SPACY_AVAILABLE = False
    print("Warning: spaCy not installed. Using basic NLP processing.")

class NLPProcessor:
    """NLP processing for resume and JD analysis"""
    
    def __init__(self):
        self.nlp = None
        if SPACY_AVAILABLE:
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except OSError:
                print("Warning: spaCy model not found. Install with: python -m spacy download en_core_web_sm")
                SPACY_AVAILABLE = False
        
        # Common stop words
        self.stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
            'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'should', 'could', 'may', 'might', 'must', 'can', 'this', 'that',
            'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
            'work', 'experience', 'years', 'year', 'month', 'months', 'job',
            'position', 'role', 'company', 'responsibilities', 'duties'
        }
        
        # Technical keywords with weights
        self.technical_keywords = {
            'javascript': 2.0, 'python': 2.0, 'java': 2.0, 'c++': 2.0, 'sql': 2.0,
            'html': 1.5, 'css': 1.5, 'react': 2.0, 'angular': 2.0, 'vue': 2.0,
            'node': 2.0, 'express': 2.0, 'django': 2.0, 'flask': 2.0, 'spring': 2.0,
            'aws': 2.0, 'azure': 2.0, 'docker': 2.0, 'kubernetes': 2.0, 'git': 1.5,
            'agile': 1.5, 'scrum': 1.5, 'api': 1.5, 'rest': 1.5, 'graphql': 2.0,
            'mongodb': 2.0, 'postgresql': 2.0, 'mysql': 2.0, 'machine learning': 2.5,
            'ai': 2.0, 'data science': 2.5, 'analytics': 2.0, 'cloud': 2.0
        }
    
    def process_text(self, text):
        """Process text and extract features"""
        if not text:
            return {
                'keywords': [],
                'skills': [],
                'entities': [],
                'bigrams': [],
                'word_count': 0
            }
        
        # Use spaCy if available
        if self.nlp:
            doc = self.nlp(text.lower())
            keywords = self._extract_keywords_spacy(doc)
            skills = self._extract_skills_spacy(doc)
            entities = self._extract_entities_spacy(doc)
            bigrams = self._extract_bigrams_spacy(doc)
        else:
            keywords = self._extract_keywords_basic(text)
            skills = self._extract_skills_basic(text)
            entities = []
            bigrams = self._extract_bigrams_basic(text)
        
        return {
            'keywords': keywords,
            'skills': skills,
            'entities': entities,
            'bigrams': bigrams,
            'word_count': len(text.split())
        }
    
    def _extract_keywords_spacy(self, doc):
        """Extract keywords using spaCy"""
        keywords = {}
        
        for token in doc:
            if (not token.is_stop and 
                not token.is_punct and 
                len(token.text) > 2 and
                token.text.lower() not in self.stop_words):
                
                weight = 1.0
                text_lower = token.text.lower()
                
                # Check if it's a technical keyword
                if text_lower in self.technical_keywords:
                    weight = self.technical_keywords[text_lower]
                elif len(token.text) > 6:
                    weight = 1.5
                
                # Prefer nouns and proper nouns
                if token.pos_ in ['NOUN', 'PROPN']:
                    weight *= 1.2
                
                keywords[text_lower] = keywords.get(text_lower, 0) + weight
        
        # Sort by frequency and return top keywords
        sorted_keywords = sorted(keywords.items(), key=lambda x: x[1], reverse=True)
        return [kw[0] for kw in sorted_keywords[:60]]
    
    def _extract_keywords_basic(self, text):
        """Basic keyword extraction without spaCy"""
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = {}
        
        for word in words:
            if len(word) > 2 and word not in self.stop_words:
                weight = 1.0
                
                if word in self.technical_keywords:
                    weight = self.technical_keywords[word]
                elif len(word) > 6:
                    weight = 1.5
                
                keywords[word] = keywords.get(word, 0) + weight
        
        sorted_keywords = sorted(keywords.items(), key=lambda x: x[1], reverse=True)
        return [kw[0] for kw in sorted_keywords[:60]]
    
    def _extract_skills_spacy(self, doc):
        """Extract skills using spaCy"""
        skill_keywords = {
            'javascript': ['javascript', 'js', 'node.js', 'react', 'vue', 'angular'],
            'python': ['python', 'django', 'flask', 'pandas', 'numpy'],
            'java': ['java', 'spring', 'hibernate', 'j2ee'],
            'c++': ['c++', 'cpp', 'c plus plus'],
            'sql': ['sql', 'mysql', 'postgresql', 'database', 'oracle'],
            'html': ['html', 'html5'],
            'css': ['css', 'css3', 'sass', 'scss', 'bootstrap'],
            'git': ['git', 'github', 'gitlab', 'version control'],
            'aws': ['aws', 'amazon web services', 'cloud'],
            'docker': ['docker', 'containerization'],
            'kubernetes': ['kubernetes', 'k8s'],
            'agile': ['agile', 'scrum', 'kanban'],
            'machine learning': ['machine learning', 'ml', 'deep learning', 'ai', 'artificial intelligence'],
            'data analysis': ['data analysis', 'analytics', 'data science'],
            'communication': ['communication', 'communicate', 'verbal', 'written'],
            'leadership': ['leadership', 'lead', 'manage', 'management'],
            'teamwork': ['teamwork', 'collaboration', 'collaborate', 'team'],
            'problem solving': ['problem solving', 'problem-solving', 'analytical'],
            'project management': ['project management', 'pm', 'project manager']
        }
        
        text_lower = doc.text.lower()
        found_skills = set()
        
        for skill, keywords in skill_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                found_skills.add(skill)
        
        return list(found_skills)
    
    def _extract_skills_basic(self, text):
        """Basic skill extraction"""
        return self._extract_skills_spacy(type('obj', (object,), {'text': text.lower()})())
    
    def _extract_entities_spacy(self, doc):
        """Extract named entities using spaCy"""
        if not self.nlp:
            return []
        
        entities = []
        for ent in doc.ents:
            if ent.label_ in ['ORG', 'PERSON', 'GPE', 'TECH']:
                entities.append({
                    'text': ent.text,
                    'label': ent.label_,
                    'start': ent.start_char,
                    'end': ent.end_char
                })
        return entities
    
    def _extract_bigrams_spacy(self, doc):
        """Extract bigrams using spaCy"""
        bigrams = []
        for i in range(len(doc) - 1):
            if (not doc[i].is_stop and not doc[i+1].is_stop and
                not doc[i].is_punct and not doc[i+1].is_punct):
                bigram = f"{doc[i].text.lower()} {doc[i+1].text.lower()}"
                if len(bigram) > 5:
                    bigrams.append(bigram)
        return bigrams[:20]
    
    def _extract_bigrams_basic(self, text):
        """Basic bigram extraction"""
        words = re.findall(r'\b\w+\b', text.lower())
        bigrams = []
        for i in range(len(words) - 1):
            if words[i] not in self.stop_words and words[i+1] not in self.stop_words:
                bigram = f"{words[i]} {words[i+1]}"
                if len(bigram) > 5:
                    bigrams.append(bigram)
        return bigrams[:20]
    
    def analyze_ats(self, resume_text):
        """Analyze resume for ATS compatibility"""
        results = {
            'overall_score': 0,
            'checks': []
        }
        
        passed_checks = 0
        total_checks = 10
        
        # Check 1: Length
        word_count = len(resume_text.split())
        length_check = {
            'title': 'Resume Length',
            'status': 'pass' if 400 <= word_count <= 800 else ('warning' if word_count < 400 else 'fail'),
            'description': f'Your resume has {word_count} words.',
            'suggestions': (
                ['Add more details about your experience and achievements', 'Include specific metrics and accomplishments']
                if word_count < 400 else
                (['Consider condensing your resume to 1-2 pages', 'Remove outdated or less relevant information']
                if word_count > 800 else ['Good length for most positions'])
            )
        }
        if length_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(length_check)
        
        # Check 2: Contact Information
        has_email = bool(re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', resume_text))
        has_phone = bool(re.search(r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', resume_text))
        contact_check = {
            'title': 'Contact Information',
            'status': 'pass' if (has_email and has_phone) else 'fail',
            'description': (
                'Email and phone number found.'
                if (has_email and has_phone) else
                f"Missing: {'Email' if not has_email else ''} {'Phone' if not has_phone else ''}"
            ),
            'suggestions': (
                [] if (has_email and has_phone) else
                ['Add a professional email address', 'Include a phone number']
            )
        }
        if contact_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(contact_check)
        
        # Check 3: Keywords
        processed = self.process_text(resume_text)
        keyword_density = len(processed['keywords'])
        keyword_check = {
            'title': 'Keyword Density',
            'status': 'pass' if keyword_density >= 20 else ('warning' if keyword_density >= 10 else 'fail'),
            'description': f'Found {keyword_density} relevant keywords.',
            'suggestions': (
                [] if keyword_density >= 20 else
                ['Include more industry-specific keywords', 'Add technical skills and tools you\'ve used']
            )
        }
        if keyword_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(keyword_check)
        
        # Check 4: Action Verbs
        action_verbs = ['developed', 'created', 'implemented', 'managed', 'led', 'designed', 'built', 'improved', 'optimized', 'achieved']
        has_action_verbs = any(verb in resume_text.lower() for verb in action_verbs)
        action_verb_check = {
            'title': 'Action Verbs',
            'status': 'pass' if has_action_verbs else 'warning',
            'description': 'Good use of action verbs found.' if has_action_verbs else 'Limited use of action verbs.',
            'suggestions': (
                [] if has_action_verbs else
                ['Start bullet points with action verbs', 'Use words like: developed, created, implemented, managed, led']
            )
        }
        if action_verb_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(action_verb_check)
        
        # Check 5: Quantifiable Achievements
        has_numbers = bool(re.search(r'\d+', resume_text))
        quantifiable_check = {
            'title': 'Quantifiable Achievements',
            'status': 'pass' if has_numbers else 'warning',
            'description': 'Numbers and metrics found.' if has_numbers else 'Limited use of numbers and metrics.',
            'suggestions': (
                [] if has_numbers else
                ['Add specific numbers (percentages, dollar amounts, timeframes)', 'Include metrics like: "increased sales by 25%" or "managed team of 10"']
            )
        }
        if quantifiable_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(quantifiable_check)
        
        # Check 6: File Format
        format_check = {
            'title': 'File Format Compatibility',
            'status': 'warning',
            'description': 'Ensure your resume is saved as .docx or .pdf for best ATS compatibility.',
            'suggestions': ['Avoid .doc (old format)', 'PDF is preferred for most ATS systems', 'Avoid images and complex formatting']
        }
        passed_checks += 0.5
        results['checks'].append(format_check)
        
        # Check 7: Skills Section
        skills_keywords = ['skills', 'technical skills', 'competencies', 'expertise']
        has_skills_section = any(keyword in resume_text.lower() for keyword in skills_keywords)
        skills_section_check = {
            'title': 'Skills Section',
            'status': 'pass' if has_skills_section else 'warning',
            'description': 'Skills section found.' if has_skills_section else 'No clear skills section identified.',
            'suggestions': (
                [] if has_skills_section else
                ['Add a dedicated skills section', 'List technical and soft skills clearly']
            )
        }
        if skills_section_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(skills_section_check)
        
        # Check 8: Education
        education_keywords = ['education', 'university', 'college', 'degree', 'bachelor', 'master', 'phd']
        has_education = any(keyword in resume_text.lower() for keyword in education_keywords)
        education_check = {
            'title': 'Education Section',
            'status': 'pass' if has_education else 'warning',
            'description': 'Education information found.' if has_education else 'Education section may be missing.',
            'suggestions': (
                [] if has_education else
                ['Include your educational background', 'List degrees, institutions, and graduation dates']
            )
        }
        if education_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(education_check)
        
        # Check 9: Experience
        experience_keywords = ['experience', 'work', 'employment', 'position', 'role', 'job']
        has_experience = any(keyword in resume_text.lower() for keyword in experience_keywords)
        experience_check = {
            'title': 'Work Experience',
            'status': 'pass' if has_experience else 'fail',
            'description': 'Work experience section found.' if has_experience else 'Work experience section may be missing.',
            'suggestions': (
                [] if has_experience else
                ['Include a work experience section', 'List companies, positions, dates, and responsibilities']
            )
        }
        if experience_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(experience_check)
        
        # Check 10: Professional Summary
        summary_keywords = ['summary', 'objective', 'profile', 'about']
        has_summary = any(keyword in resume_text.lower() for keyword in summary_keywords)
        summary_check = {
            'title': 'Professional Summary',
            'status': 'pass' if has_summary else 'warning',
            'description': 'Professional summary found.' if has_summary else 'Consider adding a professional summary.',
            'suggestions': (
                [] if has_summary else
                ['Add a 2-3 sentence professional summary at the top', 'Highlight your key qualifications and career goals']
            )
        }
        if summary_check['status'] == 'pass':
            passed_checks += 1
        results['checks'].append(summary_check)
        
        results['overall_score'] = round((passed_checks / total_checks) * 100)
        return results

