# Resume JD Matcher Backend

Python backend for the Resume-JD Matcher application using Flask, NLP, and SQLite.

## Features

- **NLP Processing**: Advanced text processing using spaCy for better keyword and skill extraction
- **Matching Engine**: Intelligent matching algorithm with fuzzy matching and weighting
- **Database**: SQLite database for storing resumes, job descriptions, and match results
- **REST API**: Complete RESTful API for frontend integration
- **ATS Analysis**: Automated ATS compatibility checking

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

## Installation

### Option 1: Quick Setup (Recommended)

Run the setup script which will install everything automatically:

```bash
cd backend
python setup.py
```

### Option 2: Manual Setup

1. **Install Python dependencies:**
```bash
cd backend
pip install -r requirements.txt
```

2. **Install spaCy language model:**
```bash
python -m spacy download en_core_web_sm
```

**Note**: If spaCy installation fails, the backend will still work using basic NLP processing.

3. **Initialize the database:**
The database will be automatically created when you run the application for the first time.

## Running the Backend

### Method 1: Using run.py (Recommended)
```bash
cd backend
python run.py
```

### Method 2: Direct execution
```bash
cd backend
python app.py
```

The server will start on `http://localhost:5000`

## Testing the Backend

You can test the API endpoints using curl or Postman:

```bash
# Test match endpoint
curl -X POST http://localhost:5000/api/match \
  -H "Content-Type: application/json" \
  -d '{"resume_text": "Your resume text here", "jd_text": "Job description here"}'

# Test ATS check
curl -X POST http://localhost:5000/api/ats-check \
  -H "Content-Type: application/json" \
  -d '{"resume_text": "Your resume text here"}'

# Get history
curl http://localhost:5000/api/history
```

## API Endpoints

### Match Resume with JD
- **POST** `/api/match`
- **Body**: `{ "resume_text": "...", "jd_text": "..." }`
- **Response**: Match results with score, skills, and keywords

### ATS Check
- **POST** `/api/ats-check`
- **Body**: `{ "resume_text": "..." }`
- **Response**: ATS analysis results

### History Management
- **GET** `/api/history` - Get all match history
- **GET** `/api/history/<id>` - Get specific history item
- **DELETE** `/api/history/<id>` - Delete specific history item
- **DELETE** `/api/history` - Clear all history

### Resume Management
- **POST** `/api/resumes` - Save a new resume
- **GET** `/api/resumes` - Get all saved resumes
- **GET** `/api/resumes/<id>` - Get specific resume
- **PUT** `/api/resumes/<id>` - Update resume
- **DELETE** `/api/resumes/<id>` - Delete resume

## Database Schema

- **resumes**: Store saved resumes
- **job_descriptions**: Store job descriptions (for future use)
- **match_results**: Store match history
- **resume_history**: Track resume versions

## NLP Features

- Keyword extraction with weighting
- Skill extraction
- Named entity recognition
- Bigram extraction
- Fuzzy matching for similar keywords

## Notes

- The database file `resume_matcher.db` will be created in the backend directory
- For production, consider using PostgreSQL or MySQL instead of SQLite
- Make sure to install the spaCy language model for better NLP processing

