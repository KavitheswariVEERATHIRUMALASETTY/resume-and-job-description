#!/usr/bin/env python3
"""
Setup script for Resume JD Matcher Backend
"""
import subprocess
import sys
import os

def install_requirements():
    """Install Python requirements"""
    print("Installing Python requirements...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✓ Requirements installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("✗ Failed to install requirements")
        return False

def download_spacy_model():
    """Download spaCy English model"""
    print("\nDownloading spaCy English model...")
    try:
        subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
        print("✓ spaCy model downloaded successfully")
        return True
    except subprocess.CalledProcessError:
        print("⚠ Warning: Failed to download spaCy model. Basic NLP will be used.")
        return False

def init_database():
    """Initialize database"""
    print("\nInitializing database...")
    try:
        from database import init_db
        init_db()
        print("✓ Database initialized successfully")
        return True
    except Exception as e:
        print(f"✗ Failed to initialize database: {e}")
        return False

def main():
    """Main setup function"""
    print("=" * 50)
    print("Resume JD Matcher Backend Setup")
    print("=" * 50)
    
    # Change to backend directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Install requirements
    if not install_requirements():
        sys.exit(1)
    
    # Download spaCy model
    download_spacy_model()
    
    # Initialize database
    if not init_database():
        sys.exit(1)
    
    print("\n" + "=" * 50)
    print("Setup completed successfully!")
    print("=" * 50)
    print("\nTo start the server, run:")
    print("  python app.py")
    print("\nThe server will be available at: http://localhost:5000")

if __name__ == "__main__":
    main()

