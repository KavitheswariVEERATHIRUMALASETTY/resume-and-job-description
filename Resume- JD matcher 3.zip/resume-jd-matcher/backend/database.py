from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker, Session
from sqlalchemy.ext.declarative import declarative_base
import os

# Get the directory where this file is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Database file path (absolute path)
DATABASE_PATH = os.path.join(BASE_DIR, 'resume_matcher.db')
DATABASE_URL = f'sqlite:///{DATABASE_PATH}'

# Create engine
engine = create_engine(
    DATABASE_URL,
    connect_args={'check_same_thread': False},
    echo=False,
    pool_pre_ping=True
)

# Create session factory
session_factory = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Create scoped session
db_session = scoped_session(session_factory)

# Base class for models
Base = declarative_base()
Base.query = db_session.query_property()

def init_db():
    """Initialize database tables"""
    try:
        # Import models to register them with Base
        from models import Resume, JobDescription, MatchResult, ResumeHistory
        
        # Create all tables
        Base.metadata.create_all(bind=engine)
        
        # Verify database was created
        if os.path.exists(DATABASE_PATH):
            file_size = os.path.getsize(DATABASE_PATH)
            print(f"[OK] Database initialized at: {DATABASE_PATH}")
            print(f"     Database size: {file_size} bytes")
        else:
            print(f"[WARNING] Database file not found at: {DATABASE_PATH}")
        
        return True
    except Exception as e:
        print(f"[ERROR] Error initializing database: {e}")
        import traceback
        print(traceback.format_exc())
        return False

def get_db():
    """Get database session"""
    return db_session

