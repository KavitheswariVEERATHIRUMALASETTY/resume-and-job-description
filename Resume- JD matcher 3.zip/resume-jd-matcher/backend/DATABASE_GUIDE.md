# SQLite Database Guide

## Database Overview

The Resume JD Matcher uses SQLite database to store:
- **Resumes**: Saved resume content with tags
- **Job Descriptions**: Stored job postings
- **Match Results**: History of resume-JD matches
- **Resume History**: Version tracking for resumes

## Database File

- **Location**: `backend/resume_matcher.db`
- **Type**: SQLite 3
- **Size**: Automatically grows as data is added

## Database Tables

### 1. `resumes` Table
Stores saved resumes with metadata.

**Columns:**
- `id` (INTEGER, Primary Key)
- `name` (VARCHAR(200)) - Resume name/title
- `content` (TEXT) - Full resume content
- `tags` (TEXT) - JSON array of tags
- `created_at` (DATETIME) - Creation timestamp
- `updated_at` (DATETIME) - Last update timestamp

### 2. `job_descriptions` Table
Stores job descriptions.

**Columns:**
- `id` (INTEGER, Primary Key)
- `title` (VARCHAR(200)) - Job title
- `company` (VARCHAR(200)) - Company name
- `content` (TEXT) - Full job description
- `location` (VARCHAR(100)) - Job location
- `salary_range` (VARCHAR(50)) - Salary information
- `created_at` (DATETIME)
- `updated_at` (DATETIME)

### 3. `match_results` Table
Stores match analysis results.

**Columns:**
- `id` (INTEGER, Primary Key)
- `resume_text` (TEXT) - Preview of resume (first 500 chars)
- `jd_text` (TEXT) - Preview of JD (first 500 chars)
- `match_score` (FLOAT) - Match percentage (0-100)
- `matching_skills` (TEXT) - JSON array of matching skills
- `missing_skills` (TEXT) - JSON array of missing skills
- `matching_keywords` (TEXT) - JSON array of matching keywords
- `resume_keyword_count` (INTEGER) - Number of keywords in resume
- `jd_keyword_count` (INTEGER) - Number of keywords in JD
- `keyword_overlap` (INTEGER) - Number of overlapping keywords
- `created_at` (DATETIME) - When match was performed

### 4. `resume_history` Table
Tracks resume versions.

**Columns:**
- `id` (INTEGER, Primary Key)
- `resume_id` (INTEGER) - Reference to resume
- `content` (TEXT) - Resume content at this version
- `version` (INTEGER) - Version number
- `created_at` (DATETIME) - When version was created

## Database Management

### Initialize Database
```bash
python init_database.py
```

### View Database Info
```bash
python db_manager.py info
```

### Clear All Data (keeps structure)
```bash
python db_manager.py clear
```

### Drop All Tables (destructive!)
```bash
python db_manager.py drop
```

## Using SQLite Command Line

You can also use SQLite command line tool:

```bash
# Open database
sqlite3 resume_matcher.db

# View all tables
.tables

# View table structure
.schema resumes

# Query data
SELECT * FROM match_results ORDER BY created_at DESC LIMIT 10;

# Exit
.exit
```

## Backup Database

To backup your database:
```bash
# Copy the database file
copy resume_matcher.db resume_matcher_backup.db

# Or use SQLite backup command
sqlite3 resume_matcher.db ".backup resume_matcher_backup.db"
```

## Database Location

The database file is created in the `backend` directory:
```
resume-jd-matcher/backend/resume_matcher.db
```

## Notes

- The database is automatically created when you first run the application
- All data persists between application restarts
- SQLite is file-based, so you can easily backup by copying the `.db` file
- For production, consider migrating to PostgreSQL or MySQL for better performance

