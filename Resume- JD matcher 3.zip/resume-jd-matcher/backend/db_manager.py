#!/usr/bin/env python3
"""
Database management utilities for Resume JD Matcher
"""
import os
import sys
from database import db_session, engine, Base
from models import Resume, JobDescription, MatchResult, ResumeHistory
from sqlalchemy import inspect

def show_database_info():
    """Display database information"""
    print("=" * 60)
    print("Database Information")
    print("=" * 60)
    
    # Database file info
    db_path = os.path.join(os.path.dirname(__file__), 'resume_matcher.db')
    if os.path.exists(db_path):
        file_size = os.path.getsize(db_path)
        print(f"\nDatabase File: {db_path}")
        print(f"File Size: {file_size:,} bytes ({file_size / 1024:.2f} KB)")
    else:
        print(f"\n[WARNING] Database file not found at: {db_path}")
        return
    
    # Table information
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    
    print(f"\nTables: {len(tables)}")
    print("-" * 60)
    
    for table_name in tables:
        try:
            # Get row count
            if table_name == 'resumes':
                count = db_session.query(Resume).count()
            elif table_name == 'job_descriptions':
                count = db_session.query(JobDescription).count()
            elif table_name == 'match_results':
                count = db_session.query(MatchResult).count()
            elif table_name == 'resume_history':
                count = db_session.query(ResumeHistory).count()
            else:
                count = 0
            
            print(f"{table_name:25} : {count:5} rows")
            
            # Show columns
            columns = inspector.get_columns(table_name)
            for col in columns[:3]:  # Show first 3 columns
                print(f"  - {col['name']:23} : {str(col['type'])}")
            if len(columns) > 3:
                print(f"  - ... and {len(columns) - 3} more columns")
                
        except Exception as e:
            print(f"{table_name:25} : Error - {e}")
    
    print("=" * 60)

def clear_database():
    """Clear all data from database (keeps structure)"""
    print("=" * 60)
    print("Clear Database")
    print("=" * 60)
    
    confirm = input("\n⚠ WARNING: This will delete ALL data. Continue? (yes/no): ")
    if confirm.lower() != 'yes':
        print("Operation cancelled.")
        return
    
    try:
        db_session.query(MatchResult).delete()
        db_session.query(ResumeHistory).delete()
        db_session.query(JobDescription).delete()
        db_session.query(Resume).delete()
        db_session.commit()
        print("\n[SUCCESS] All data cleared successfully")
    except Exception as e:
        db_session.rollback()
        print(f"\n[ERROR] Error clearing database: {e}")

def drop_database():
    """Drop all tables (destructive!)"""
    print("=" * 60)
    print("Drop Database Tables")
    print("=" * 60)
    
    confirm = input("\n⚠ WARNING: This will DELETE ALL TABLES and DATA. Continue? (yes/no): ")
    if confirm.lower() != 'yes':
        print("Operation cancelled.")
        return
    
    try:
        Base.metadata.drop_all(bind=engine)
        print("\n[SUCCESS] All tables dropped successfully")
        print("Run init_database.py to recreate tables")
    except Exception as e:
        print(f"\n[ERROR] Error dropping tables: {e}")

def main():
    """Main menu"""
    if len(sys.argv) > 1:
        command = sys.argv[1]
        if command == 'info':
            show_database_info()
        elif command == 'clear':
            clear_database()
        elif command == 'drop':
            drop_database()
        else:
            print(f"Unknown command: {command}")
            print("Usage: python db_manager.py [info|clear|drop]")
    else:
        show_database_info()
        print("\nAvailable commands:")
        print("  python db_manager.py info  - Show database information")
        print("  python db_manager.py clear - Clear all data")
        print("  python db_manager.py drop  - Drop all tables")

if __name__ == "__main__":
    main()

