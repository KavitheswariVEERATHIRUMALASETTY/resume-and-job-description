from sqlalchemy import Column, Integer, String, Text, Float, DateTime, JSON
from database import Base
from datetime import datetime

class Resume(Base):
    """Resume model"""
    __tablename__ = 'resumes'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    content = Column(Text, nullable=False)
    tags = Column(Text)  # JSON string of tags
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self):
        return f'<Resume {self.name}>'

class JobDescription(Base):
    """Job Description model"""
    __tablename__ = 'job_descriptions'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    company = Column(String(200))
    content = Column(Text, nullable=False)
    location = Column(String(100))
    salary_range = Column(String(50))
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self):
        return f'<JobDescription {self.title}>'

class MatchResult(Base):
    """Match Result model"""
    __tablename__ = 'match_results'
    
    id = Column(Integer, primary_key=True)
    resume_text = Column(Text)  # Preview of resume
    jd_text = Column(Text)  # Preview of JD
    match_score = Column(Float, nullable=False)
    matching_skills = Column(Text)  # JSON string
    missing_skills = Column(Text)  # JSON string
    matching_keywords = Column(Text)  # JSON string
    resume_keyword_count = Column(Integer)
    jd_keyword_count = Column(Integer)
    keyword_overlap = Column(Integer)
    created_at = Column(DateTime, default=datetime.now)
    
    def __repr__(self):
        return f'<MatchResult {self.match_score}%>'

class ResumeHistory(Base):
    """Resume History model (for tracking resume versions)"""
    __tablename__ = 'resume_history'
    
    id = Column(Integer, primary_key=True)
    resume_id = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    version = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.now)
    
    def __repr__(self):
        return f'<ResumeHistory {self.resume_id} v{self.version}>'

