#!/usr/bin/env python3
"""
Database initialization script for Resume JD Matcher
Creates and initializes the SQLite database with all required tables
"""
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import init_db, engine, Base
from models import Resume, JobDescription, MatchResult, ResumeHistory

def create_database():
    """Create database and all tables"""
    print("=" * 60)
    print("Resume JD Matcher - Database Initialization")
    print("=" * 60)
    
    try:
        # Import all models to ensure they're registered
        print("\n1. Importing models...")
        print("   [OK] Resume model")
        print("   [OK] JobDescription model")
        print("   [OK] MatchResult model")
        print("   [OK] ResumeHistory model")
        
        # Create all tables
        print("\n2. Creating database tables...")
        Base.metadata.create_all(bind=engine)
        print("   [OK] Tables created successfully")
        
        # Verify tables were created
        print("\n3. Verifying database structure...")
        from sqlalchemy import inspect
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        
        expected_tables = ['resumes', 'job_descriptions', 'match_results', 'resume_history']
        print(f"\n   Found {len(tables)} table(s):")
        for table in tables:
            status = "[OK]" if table in expected_tables else "[?]"
            print(f"   {status} {table}")
        
        # Check if all expected tables exist
        missing_tables = [t for t in expected_tables if t not in tables]
        if missing_tables:
            print(f"\n   [WARNING] Missing tables: {', '.join(missing_tables)}")
        else:
            print("\n   [OK] All expected tables are present")
        
        # Display table schemas
        print("\n4. Table schemas:")
        for table_name in expected_tables:
            if table_name in tables:
                columns = inspector.get_columns(table_name)
                print(f"\n   Table: {table_name}")
                for col in columns:
                    print(f"     - {col['name']}: {col['type']}")
        
        print("\n" + "=" * 60)
        print("[SUCCESS] Database initialization completed successfully!")
        print("=" * 60)
        print(f"\nDatabase file location: {os.path.join(os.path.dirname(__file__), 'resume_matcher.db')}")
        print("\nYou can now start the backend server with:")
        print("  python run.py")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print(f"\n[ERROR] Error initializing database: {e}")
        import traceback
        print(traceback.format_exc())
        return False

if __name__ == "__main__":
    success = create_database()
    sys.exit(0 if success else 1)

