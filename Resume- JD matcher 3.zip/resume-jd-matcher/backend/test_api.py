#!/usr/bin/env python3
"""
Simple test script to verify the backend API is working
"""
import requests
import json

BASE_URL = "http://localhost:5000/api"

def test_match():
    """Test the match endpoint"""
    print("Testing /api/match endpoint...")
    data = {
        "resume_text": "Software Engineer with 5 years of experience in Python, JavaScript, and React. Strong background in web development and cloud technologies.",
        "jd_text": "We are looking for a Software Engineer with experience in Python and JavaScript. Knowledge of React and cloud technologies is preferred."
    }
    
    try:
        response = requests.post(f"{BASE_URL}/match", json=data)
        if response.status_code == 200:
            result = response.json()
            print(f"✓ Match test passed! Score: {result.get('score', 'N/A')}%")
            return True
        else:
            print(f"✗ Match test failed: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"✗ Match test failed: {e}")
        return False

def test_ats_check():
    """Test the ATS check endpoint"""
    print("\nTesting /api/ats-check endpoint...")
    data = {
        "resume_text": "John Doe\nEmail: john@example.com\nPhone: 123-456-7890\n\nSoftware Engineer with 5 years of experience. Developed web applications using Python and JavaScript."
    }
    
    try:
        response = requests.post(f"{BASE_URL}/ats-check", json=data)
        if response.status_code == 200:
            result = response.json()
            print(f"✓ ATS check test passed! Overall Score: {result.get('overall_score', 'N/A')}%")
            return True
        else:
            print(f"✗ ATS check test failed: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"✗ ATS check test failed: {e}")
        return False

def test_history():
    """Test the history endpoint"""
    print("\nTesting /api/history endpoint...")
    
    try:
        response = requests.get(f"{BASE_URL}/history")
        if response.status_code == 200:
            result = response.json()
            print(f"✓ History test passed! Found {len(result.get('history', []))} items")
            return True
        else:
            print(f"✗ History test failed: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"✗ History test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("Backend API Test Suite")
    print("=" * 60)
    print("\nMake sure the backend server is running on http://localhost:5000")
    print("=" * 60)
    
    results = []
    results.append(("Match Endpoint", test_match()))
    results.append(("ATS Check Endpoint", test_ats_check()))
    results.append(("History Endpoint", test_history()))
    
    print("\n" + "=" * 60)
    print("Test Results Summary")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{name}: {status}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("All tests passed! Backend is working correctly.")
        return 0
    else:
        print("Some tests failed. Please check the backend server.")
        return 1

if __name__ == "__main__":
    try:
        import requests
    except ImportError:
        print("Error: requests library not installed.")
        print("Install it with: pip install requests")
        exit(1)
    
    exit(main())

