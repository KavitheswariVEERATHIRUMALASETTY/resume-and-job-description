#!/usr/bin/env python3
"""
Run script for Resume JD Matcher Backend
"""
import sys
import os

# Add the backend directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app

if __name__ == '__main__':
    print("=" * 60)
    print("Resume JD Matcher Backend Server")
    print("=" * 60)
    print("\nStarting server...")
    print("Server URL: http://localhost:5000")
    print("API Base URL: http://localhost:5000/api")
    print("\nPress CTRL+C to stop the server")
    print("=" * 60)
    
    try:
        app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
    except KeyboardInterrupt:
        print("\n\nServer stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nError starting server: {e}")
        sys.exit(1)

