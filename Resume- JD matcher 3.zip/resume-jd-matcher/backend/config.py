"""
Configuration file for the Resume JD Matcher backend
"""
import os

# Flask configuration
DEBUG = True
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')

# Database configuration
DATABASE_NAME = 'resume_matcher.db'
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, DATABASE_NAME)
DATABASE_URL = f'sqlite:///{DATABASE_PATH}'

# API configuration
API_PREFIX = '/api'
CORS_ORIGINS = ['*']  # In production, specify actual origins

# NLP configuration
SPACY_MODEL = 'en_core_web_sm'
USE_SPACY = True  # Set to False to use basic NLP

# Matching configuration
KEYWORD_WEIGHT = 0.5  # 50% weight for keywords
SKILL_WEIGHT = 0.5    # 50% weight for skills
BIGRAM_BONUS_MAX = 5  # Maximum bonus points for bigram matches
COMPLETION_BONUS = 5  # Bonus for having all required skills

# File upload configuration
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx'}

